THE STRONGEST GUNMASTER — Vercel-ready static website

This package contains the latest 3D mobile HTML game as index.html.

To deploy: Extract this ZIP, then upload the folder to a Vercel project (or push the folder to a Git repository and import it into Vercel). No build command or framework is needed.

After deployment, set the project name to the-strongest-gunmaster if available. Your actual URL is assigned by Vercel.

Requires internet to load Three.js from cdnjs. This is a prototype, not a multiplayer Roblox game.
